import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DonarcardComponent } from './donarcard.component';

describe('DonarcardComponent', () => {
  let component: DonarcardComponent;
  let fixture: ComponentFixture<DonarcardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DonarcardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DonarcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
