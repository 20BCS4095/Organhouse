import { Component, Injectable, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-donarcard',
  templateUrl: './donarcard.component.html',
  styleUrls: ['./donarcard.component.css']
})
export class DonarcardComponent {
  constructor(private _snackBar: MatSnackBar,public auth:AuthService,private formBulider: FormBuilder,private router:Router){
  
  }
  answer:any;
Signup(){
this.auth.getOrgan().subscribe(res=>{
this.answer=res
})
}
}
