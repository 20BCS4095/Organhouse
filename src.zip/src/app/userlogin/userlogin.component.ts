import { Component } from '@angular/core';
import { FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent {
  loginForm!:FormGroup
  answer:any;
  constructor(private _snackBar: MatSnackBar,private FormGroup:FormBuilder,public auth:AuthService,private _http:HttpClient,private router:Router){
  }
  ngOnInit(): void{
    this.loginForm=this.FormGroup.group({
      'email':['',Validators.required],
      'password':['',Validators.required]
    })
  }
  login(){
 
this.auth.getUserlogin(this.loginForm.value.email).subscribe(res=>{
  if(res.toString()=="false"){
    this._snackBar.open('User not found', 'Ok', {
      duration: 5000,
    });
  }
  else{
  this.answer=res
  const user =this.loginForm.value.password==this.answer.pass
  
  if(user){
    this._snackBar.open('Login successfull', 'Ok', {
      duration: 5000,
    });
    this.loginForm.reset();
  this.router.navigate(['userhome'])
  }
  else{
    
    this._snackBar.open('Password incorrect', 'Ok', {
      duration: 5000,
    });
  }
}
})
  }
  
  

}
