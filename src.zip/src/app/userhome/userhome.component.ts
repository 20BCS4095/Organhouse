import { Component, Injectable, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent {
  Form!: FormGroup;
  selectedMenu: any = 'Home';
  goTo(paramText: string) {
    this.selectedMenu = paramText;
  }
   
  constructor(private _snackBar: MatSnackBar,public auth:AuthService,private formBulider: FormBuilder,private router:Router){
  
  }
  bloodA:any;
  leaves: any[] = [];
  ngOnInit(): void {
    this.Form=this.formBulider.group({
  'name':[null,[Validators.required]],
  'pno':[null,[Validators.required,Validators.minLength(10)]],
  'place':[null,[Validators.required]],
  'blood':[null,[Validators.required]],
  'type':[null,[Validators.required]],
  'type1':[null,[Validators.required]],
  'type2':[null,[Validators.required]],
  'type3':[null,[Validators.required]]
    })
  }
  Signup(){
    
this.auth.getBlood().subscribe(res=>{
  this.bloodA=res
 console.log(this.bloodA.A)
})
  }
 login(){

this.auth.postorgan(this.Form.value).subscribe(res=>{
  this.router.navigate(['donarcard'])  
})
this.router.navigate(['donarcard'])  
 }
 onSubmit(form:NgForm) {
  const name =form.value.name
  const age=form.value.age
  const bloodgroup=form.value.bloodgroup
  const units=form.value.units
  let url = "http://localhost:5000/leaves"
  this.auth.postuserblood({name,age,bloodgroup,units}).subscribe(res => {
    form.reset();
    alert("Submitted Sucesssfully");
  });
}
}
