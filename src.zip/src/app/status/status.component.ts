import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent {
  data: any[] | undefined;
  constructor(private http:HttpClient){}
  ngOnInit(): void {
    let url = "http://localhost:5000/leaves"
    this.http.get(url).subscribe((response: any) => {
      this.data = response;
    });
  }


}
