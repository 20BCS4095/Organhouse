import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent {
  loginForm!:FormGroup
  answer:any;
  constructor(private FormGroup:FormBuilder,public auth:AuthService,private _http:HttpClient,private router:Router){
  }
  ngOnInit(): void{
    this.loginForm=this.FormGroup.group({
      'email':['',Validators.required],
      'password':['',Validators.required]
    })
  }
  login(){
 
this.auth.getAdminlogin(this.loginForm.value.email).subscribe(res=>{
  if(res.toString()=="false"){
    alert("user not found")
  }
  else{
  this.answer=res
  const user =this.loginForm.value.password==this.answer.pass
  
  if(user){
    alert("login sucess")
    this.loginForm.reset();
  this.router.navigate(['adminhome'])
  }
  else{
    alert("password incorrect")
  }
}
})
  }
}
