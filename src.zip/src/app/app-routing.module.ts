import { StatusComponent } from './status/status.component';
import { DonarcardComponent } from './donarcard/donarcard.component';
import { UpdateinfoComponent } from './updateinfo/updateinfo.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AdminsigninComponent } from './adminsignin/adminsignin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { UsersigninComponent } from './usersignin/usersignin.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'userlogin',component:UserloginComponent},
  {path:'usersignin',component:UsersigninComponent},
  {path:'adminlogin',component:AdminloginComponent},
  {path:'adminsignin',component:AdminsigninComponent},
  {path:'adminhome',component:AdminhomeComponent},
  {path:'userhome',component:UserhomeComponent},
  {path:'updateinfo',component:UpdateinfoComponent},
  {path:"donarcard",component:DonarcardComponent},
  {path:"status",component:StatusComponent},
  {path:'',redirectTo:'/home',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
