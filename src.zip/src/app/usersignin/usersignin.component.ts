
import { Component, Injectable, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-usersignin',
  templateUrl: './usersignin.component.html',
  styleUrls: ['./usersignin.component.css']
})
export class UsersigninComponent {
  Form!: FormGroup;  
  
  constructor(private _snackBar: MatSnackBar,public auth:AuthService,private formBulider: FormBuilder,private router:Router){
  
  }
  ngOnInit(): void {
    this.Form=this.formBulider.group({
  'name':[null,[Validators.required]],
  'email':[null,[Validators.required,Validators.email]],
  'password':[null,[Validators.required,Validators.minLength(8)]],
  'repassword':[null,[Validators.required,Validators.minLength(8)]]
    })
  }
  SignUp(){
    this.auth.getDatauser(this.Form.value.email).subscribe(
      res=>{
        const user=res
        
        if(user.toString()=="true"){
          
          this._snackBar.open('User Already Existed', 'Ok', {
            duration: 5000,
          });
        }
        else{
          if(this.Form.value.name==null){
      
            this._snackBar.open('Enter the name field', 'Ok', {
              duration: 5000,
            });
          } 
          else if(this.Form.value.email==null){
        this._snackBar.open('Enter valid Email', 'Ok', {
          duration: 5000,
        });
          }
          else if(this.Form.value.password==null){
            this._snackBar.open('Enter password ', 'Ok', {
              duration: 5000,
            });
          }
          else if(this.Form.value.password.toString().length<8){
            this._snackBar.open('Enter Strong Password', 'Ok', {
              duration: 5000,
            });
            }
          else if(this.Form.value.password!=this.Form.value.repassword ){
        this._snackBar.open('Password mismatch', 'Ok', {
          duration: 5000,
        });
          }
          
          else{
            this.auth.postDatauser(this.Form.value).subscribe(res=>{
              this._snackBar.open('Registration successfull', 'Ok', {
                duration: 5000,
              });
            this.Form.reset();
            this.router.navigate(['userlogin']) 
          },err=>{
            this._snackBar.open('cannot register', 'Ok', {
              duration: 5000,
            });
          })
      
          }
        }
      }
    )
 
  }
  
}
