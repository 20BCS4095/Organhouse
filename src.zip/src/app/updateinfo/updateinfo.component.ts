
import { Component, Injectable, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-updateinfo',
  templateUrl: './updateinfo.component.html',
  styleUrls: ['./updateinfo.component.css']
})
export class UpdateinfoComponent {
  Form!: FormGroup;
  constructor(private _snackBar: MatSnackBar,public auth:AuthService,private formBulider: FormBuilder,private router:Router){
  
  }
  ngOnInit(): void {
    this.Form=this.formBulider.group({
  'blood':[null,[Validators.required]],
  'count':[null,[Validators.required,Validators.email]]
    })
  }
  SignUp(){
  this.auth.postBlood(this.Form.value).subscribe(res=>{
    this.router.navigate(['adminhome'])
    console.log(this.Form.value.blood)  
  })
  this.router.navigate(['adminhome']) 
  }
}
