import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgIf } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminsigninComponent } from './adminsignin/adminsignin.component';
import { UsersigninComponent } from './usersignin/usersignin.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatStepperModule} from '@angular/material/stepper';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatCardModule} from '@angular/material/card';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatIconModule} from '@angular/material/icon';
import { MatPseudoCheckbox } from '@angular/material/core';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { UserhomeComponent } from './userhome/userhome.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { UpdateinfoComponent } from './updateinfo/updateinfo.component';
import { DonarcardComponent } from './donarcard/donarcard.component';
import { StatusComponent } from './status/status.component';
const material=[
  MatCardModule,
  MatStepperModule,
  MatFormFieldModule,
 MatInputModule,
 MatTooltipModule,
 MatButtonToggleModule,
 MatToolbarModule,
 MatButtonModule,
 MatIconModule,
 MatPseudoCheckbox,
 MatProgressSpinnerModule,

]
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserloginComponent,
    AdminloginComponent,
    AdminsigninComponent,
    UsersigninComponent,
    UserhomeComponent,
    AdminhomeComponent,
    UpdateinfoComponent,
    DonarcardComponent,
    StatusComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    NgIf,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
 BrowserAnimationsModule,
 MatProgressSpinnerModule,
 MatStepperModule,
 MatCardModule,
 MatSnackBarModule,
 MatIconModule,MatTooltipModule,
 MatFormFieldModule,

  ],
  providers: [],
  bootstrap: [AppComponent],
exports:[FormsModule,
ReactiveFormsModule]
  
})
export class AppModule { }
