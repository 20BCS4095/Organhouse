import { Component, Injectable, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent {

  selectedMenu: any = 'Home';
  
  goTo(paramText: string) {
    this.selectedMenu = paramText;
  }
  
  constructor(private _snackBar: MatSnackBar,private http:HttpClient,public auth:AuthService,private formBulider: FormBuilder,private router:Router){}
    ngOnInit(): void {
      let url = "http://localhost:5000/leaves"
      this.http.get(url).subscribe((response: any) => {
        this.data = response;
      });
    }
  data: any[] | undefined;
  

approveLeave(leave:any)
{

let url = `http://localhost:5000/update/${leave.Name}`
this.http.put(url,leave).subscribe((response: any) => {
});
}

rejectLeave(leave:any)
{

  let url = `http://localhost:5000/reject/${leave.Name}`
this.http.put(url,leave).subscribe((response: any) => {
});
}


  bloodA:any;
 

  Signup(){
    
this.auth.getBlood().subscribe(res=>{
  this.bloodA=res
 console.log(this.bloodA.A)
})
  }
}
