import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(public _http:HttpClient) { }
  postDatauser(userData:any){
    return this._http.post("http://localhost:5000/usersignup",userData)
  }
  getDatauser(dat:any){
    return this._http.get("http://localhost:5000/userget/"+dat.toString());
  }
  postDataadmin(userData:any){
    return this._http.post("http://localhost:5000/adminsignup",userData)
  }
  postBlood(data:any){
    return this._http.post("http://localhost:5000/updateblood",data)
  }
  getBlood(){
    return this._http.get("http://localhost:5000/blood");
  }
  getDataadmin(dat:any){
    return this._http.get("http://localhost:5000/adminget/"+dat.toString());
  }
  getAdminlogin(data:any){
    return this._http.get("http://localhost:5000/Adminlogin/"+data.toString());
  }
  getUserlogin(data:any){
    return this._http.get("http://localhost:5000/Userlogin/"+data.toString());
  }
  postorgan(data:any){
    return this._http.post("http://localhost:5000/postorgan",data)
  }
  getOrgan(){
    return this._http.get("http://localhost:5000/getorgan")
  }
  postuserblood(data:any){
    return this._http.post("http://localhost:5000/leaves",data)
  }
}
